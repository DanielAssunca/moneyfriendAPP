<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class formaspgto_modinscri extends Model
{
    //
}
