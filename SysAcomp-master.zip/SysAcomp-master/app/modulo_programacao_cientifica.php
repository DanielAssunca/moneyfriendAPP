<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class modulo_programacao_cientifica extends Model
{
    //
}
