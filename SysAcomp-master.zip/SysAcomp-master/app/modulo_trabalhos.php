<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class modulo_trabalhos extends Model
{
    //
}
